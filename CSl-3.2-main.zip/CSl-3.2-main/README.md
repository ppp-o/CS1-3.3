# CSl-3.2

This is a Geography quiz GUI based on menu interacts with an array of questions, there are defined class(es) and objects within the code. The questions are multiple choice and a record of correct/incorrect answers is kept, and statistics gathered about the responses. The GUI has a simple layout with home, next and quit bottoms. The quiz/GUI is for kids between the ages of 7-12.
